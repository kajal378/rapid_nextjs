import Image from "next/image";
import HomePage from "./(screens)/home/page";

export default function Home() {
  return (
     <>
          <HomePage />
          
     </>
  );
}

